var name = document.getElementById("nome");
var cor = document.querySelector("#cor");
var botao = document.querySelector("#btn");
var titulo = document.querySelector("#titulo");

cor.addEventListener("change", function () {
  document.body.style.color = "#FFF";
  document.body.style.backgroundColor = cor.value;
});

botao.addEventListener("click", function (e) {
  e.preventDefault();
  alert("Bem-vindo " + nome.value);
});

window.onload = function () {
  var corFav = prompt("Qual a sua cor favorita?");
  var pX = prompt("Digite um valor de posição eixo X");
  var pY = prompt("Digite um valor de posição eixo Y");

  var alvo = document.querySelector("#alvo");

  alvo.style.marginLeft = pX + "vw";
  alvo.style.marginTop = pY + "vh";
  alvo.style.backgroundColor = corFav;
};
